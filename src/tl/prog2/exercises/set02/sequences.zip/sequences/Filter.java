package tl.prog2.exercises.set02.sequences;

public interface Filter {

    Sequence sequence = null;

    boolean testPassCondition(int element);

}
