package tl.prog2.exercises.set02.sequences;

public interface Sequence {
    public boolean hasNext();
    public int nextElement();
}
